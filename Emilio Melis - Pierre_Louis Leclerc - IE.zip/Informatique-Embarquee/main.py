#---------------------------------------------------------------------------------------------
# Importation des librairies
#---------------------------------------------------------------------------------------------

from machine import Pin
import time
from BME280 import *
from ConfigMateriel_pico import *
from machine import Pin, PWM
from SCD41 import *
from adafruit_sgp40 import *
import ILI9341
import xglcd_font
from Colorimetrie import *
from Affichage_Graphique import *
from xpt2046 import *

#---------------------------------------------------------------------------------------------
# Initialisation des variables
#---------------------------------------------------------------------------------------------

Ltemp =[]
Lpress = []
Lhumi = []
LCO2 = []

voc_index = None
last_cov = None
last_co2 = None

i = 0

BP_press_flag = False
Affiche_Ecran1_flag = True
Affiche_Ecran2_flag = False
Interrupt_pin = None
fond_ecran1_flag = True
manageBrightness_flag = False

#---------------------------------------------------------------------------------------------
# Initialisation de l'écran TFT et des polices de caractères
#---------------------------------------------------------------------------------------------

spi_tft = machine.SPI(0)
tft = ILI9341.Display(spi_tft, dc = TFT_DC_pin, cs = SPI_CS_pin, rst = TFT_RESET_pin, rotation = 90)
tft.clear()

def TouchkeepYA(x, y):
    global Touch_press_flag, Affiche_Ecran1_flag, Affiche_Ecran2_flag, fond_ecran1_flag

    Xe_touch = x
    Ye_touch = y

    if Affiche_Ecran1_flag == True:
        Affiche_Ecran1_flag = False
        Affiche_Ecran2_flag = True
        fond_ecran1_flag = False
        tft.clear()

    elif Affiche_Ecran2_flag == True:
        if (Xe_touch >0 and Ye_touch < 170):
            Affiche_Ecran1_flag = True
            Affiche_Ecran2_flag = False
            fond_ecran1_flag = True
            tft.clear()
        
        if (Xe_touch > 10 and Ye_touch > 170 and Xe_touch < 110 and Ye_touch < 230):
            tft.clear()
        
        if (Xe_touch >150 and Ye_touch > 170 and Xe_touch < 225):
            Affichage.Echelle_choix_Gamma(-1)

        if (Xe_touch >225 and Ye_touch > 170):
            Affichage.Echelle_choix_Gamma(1)
        
    Touch_press_flag = True

Touchscreen = Touch(spi_tft, Touch_Screen_CS_pin, Touch_Interrupt_pin, int_handler = TouchkeepYA, width = 240, height = 320, rotation = 90, x_min = 157, x_max = 1841, y_min = 200, y_max = 1947) 


print('Loading fonts...')

print('Loading unispace')
unispace = xglcd_font.XglcdFont('fonts/Unispace12x24.c', 12, 24)

print('Loading unispaceExt')
unispaceExt = xglcd_font.XglcdFont('fonts/UnispaceExt12x24.c', 12, 24, letter_count=224)

print('Fonts loaded.')



Affichage = TFT_affichage(tft, unispaceExt)

#---------------------------------------------------------------------------------------------
# Initialisation des capteurs
#---------------------------------------------------------------------------------------------

i2c = I2C(0, sda = SDA_pin, scl = SCL_pin, freq= Freq_i2c)
adr = i2c.scan ()

print ('Adresse peripherique I2C :', adr)



Id_BME280 = i2c.readfrom_mem(BME280_I2C_ADR, BME280_CHIP_ID_ADDR, 1)

print ('Valeur Id_BME280 : ', hex (Id_BME280[0]))

capteur_BME280 = BME280 (BME280_I2C_ADR, i2c)
capteur_BME280.Calibration_Param_Load()



temp_BME=capteur_BME280.read_temp()
press_BME=capteur_BME280.read_pression()
hum_BME=capteur_BME280.read_humidity()

sgp40_capteur_cov = SGP40 (i2c)

print("SGP40 Serial number :", [hex(i) for i in sgp40_capteur_cov._serial_number])



voc_index = sgp40_capteur_cov.measure_index(temp_BME, hum_BME)

capteur_SCD41 = SCD4X (i2c, SCD4X_DEFAULT_ADDR)
capteur_SCD41.stop_periodic_measurement()

print("Serial number :", [hex(i) for i in capteur_SCD41.serial_number])



capteur_SCD41.set_ambient_pressure(int(press_BME))
capteur_SCD41.start_periodic_measurement()

#---------------------------------------------------------------------------------------------
# Fonctions de gestion des interruptions sur les boutons poussoirs
#---------------------------------------------------------------------------------------------

def reset():
    LCO2.clear()
    Lhumi.clear()
    Ltemp.clear()
    Lpress.clear()

def BP_callback (pin) :
    global BP_press_flag, interrupt_pin
    interrupt_pin = pin 
    BP_press_flag = True

def boutonOn():
    global Affiche_Ecran1_flag, Affiche_Ecran2_flag, fond_ecran1_flag
    global BP_press_flag, interrupt_pin, manageBrightness_flag
    global LCO2,Lhumi,Ltemp,Lpress
    if Affiche_Ecran1_flag == True :
        if interrupt_pin == BP_BACKLITE_GAUCHE_pin:
            Affiche_Ecran1_flag = False
            fond_ecran1_flag = False
            Affiche_Ecran2_flag = True
            tft.clear()
    elif Affiche_Ecran2_flag == True :
        if interrupt_pin == BP_ECRAN2_pin:
            Affiche_Ecran1_flag = True
            fond_ecran1_flag = True
            Affiche_Ecran2_flag = False
            tft.clear()
        elif(manageBrightness_flag):
            if interrupt_pin == BP_BACKLITE_GAUCHE_pin:
                Affichage.Echelle_choix_Gamma(-1)
            elif interrupt_pin == BP_BACKLITE_DROITE_pin:
                Affichage.Echelle_choix_Gamma(1)
        if interrupt_pin == BP_BACKLITE_VALIDE_pin:
            manageBrightness_flag = not manageBrightness_flag
            Affichage.Echelle_choix_Gamma(0)
    if interrupt_pin == BP_RESET_min_max_pin:
        LCO2.clear()
        Lhumi.clear()
        Ltemp.clear()
        Lpress.clear()
        tft.clear()
        Affiche_Ecran1_flag = True
        fond_ecran1_flag = True
    BP_press_flag = False
            

Time_Out_screen2 = False

def Touch(x, y):
    global Touch_press_flag, Affiche_ecran_1_flag, Affiche_ecran_2_flag, Time_Out_screen2

    Xe_touch = x
    Ye_touch = y

    if Affiche_ecran_1_flag == True:
        if ((Xe_touch > 0 and Ye_touch > 0 and Xe_touch < 319 and Ye_touch < 195)
            or (Xe_touch > 0 and Ye_touch >= 195 and Xe_touch < (10 + 100))):

            Affiche_ecran_1_flag = False
            Affiche_ecran_2_flag = True
            Time_Out_screen2 = True
        
        if (Xe_touch >150 and Ye_touch < 195 and Xe_touch < 225):
            Affichage.Echelle_choix_Gamma(-1)

        if (Xe_touch >225 and Ye_touch < 195):
            Affichage.Echelle_choix_Gamma(1)

    elif Affiche_ecran_2_flag == True:
        if (Xe_touch >0 and Ye_touch < 195):
            Affiche_ecran_1_flag = True
            Affiche_ecran_2_flag = False
        
        if (Xe_touch > 10 and Ye_touch > 195 and Xe_touch < 110 and Ye_touch < 230):
            tft.clear()
        
        if (Xe_touch >150 and Ye_touch < 195 and Xe_touch < 225):
            Affichage.Echelle_choix_Gamma(-1)

        if (Xe_touch >225 and Ye_touch < 195):
            Affichage.Echelle_choix_Gamma(1)
        
    Touch_press_flag = True

Time_Out_screen2 = False




#---------------------------------------------------------------------------------------------
# Initialisation des interruptions sur les boutons poussoirs
#---------------------------------------------------------------------------------------------

BP_RESET_min_max_pin.irq(handler = BP_callback, trigger = Pin.IRQ_FALLING)
BP_ECRAN2_pin.irq(handler = BP_callback, trigger = Pin.IRQ_FALLING)
BP_BACKLITE_GAUCHE_pin.irq(handler = BP_callback, trigger = Pin.IRQ_FALLING)
BP_BACKLITE_VALIDE_pin.irq(handler = BP_callback, trigger = Pin.IRQ_FALLING)
BP_BACKLITE_DROITE_pin.irq(handler = BP_callback, trigger = Pin.IRQ_FALLING)


#---------------------------------------------------------------------------------------------
# Fonctions de mesures des capteurs
#---------------------------------------------------------------------------------------------

def BME():
    global Ltemp, Lpress, Lhumi
    temp = capteur_BME280.read_temp()
    press = capteur_BME280.read_pression()
    humi = capteur_BME280.read_humidity()
    Ltemp.append(int(temp))
    Lpress.append(int(press))
    Lhumi.append(int(humi))
    return None

def CO2():
    global LCO2, i, last_co2
    if capteur_SCD41.data_ready and i%5 == 0 and i!=0:
        co2 = capteur_SCD41.CO2
        LCO2.append(int(co2))
        if len(LCO2) <= 1:
            last_co2 = "wait"
        else:
            last_co2 = int(LCO2[-2])
    else:
        if(len(LCO2) == 0):
            LCO2.append(0)
            last_co2 = 0
    return None

def COV():
    global voc_index, last_cov, Ltemp, Lhumi
    if(voc_index == None):
        last_cov = 0
    else:
        last_cov = voc_index
    voc_index = sgp40_capteur_cov.measure_index(Ltemp[-1], Lhumi[-1])
    return None

#---------------------------------------------------------------------------------------------
# Boucle principale du programme
#---------------------------------------------------------------------------------------------

while True:
    if int(i) == i:
        BME()
        CO2()
        COV()
    
        if Affiche_Ecran1_flag == True:
            if fond_ecran1_flag == True:
                Affichage.fond_ecran1()
                fond_ecran1_flag = False
            Affichage.ecran_1(str("+"+str(Ltemp[-1])+" °C"),str(str(Lhumi[-1])+" %"),str(str(Lpress[-1])+" hPa"),str(str(LCO2[-1])+" ppm"),str(voc_index),last_co2,last_cov)
            
        if Affiche_Ecran2_flag == True:
            if(min(LCO2) == 0 and len(LCO2) > 1):
                LCO2.remove(0)
            Affichage.tableau_ecran_2(Ltemp,Lhumi,Lpress,LCO2)
    
    if BP_press_flag == True:
        boutonOn()
        time.sleep(0.1)
    
    time.sleep(0.25)
    i+=0.25