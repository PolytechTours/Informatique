# Utilisation écran TFT DFRobot DFR0665
# Communication SPI
# Test écran TFT et Test dalle tactile
# Vérification de la calibration
# Cible : Raspberry Pi pico
# Validé le 16.03.2022
#   Pour rotation = 0
#   Pour rotation = 90
#   Pour rotation = 180
#   Pour rotation = 270
# Validé le 21.03.2022
# Source : http://electroniqueamateur.blogspot.com/2021/06/utilisation-dun-ecran-tactile-tft-spi.html
from ConfigMateriel_pico import *
import machine
import time
from ILI9341 import ili9341
from ILI9341 import xglcd_font
from xpt2046 import *

#-------------------------------------------------------------------------------
def routine_touch(x, y):
    '''
    Routine d'interruption appelée lors d'un appui sur la dalle tactile
    Args : (x,y)
        Coordonnées écran TFT retournée après mapping avec
        les coordonnées du point d'appui sur la dalle tactile
    '''
    global Touch_press_flag, Affiche_ecran_1_flag, Affiche_ecran_2_flag, Time_Out_screen2

    Xe_touch = x
    Ye_touch = y

    if Affiche_ecran_1_flag == True:
        if ((Xe_touch > 0 and Ye_touch > 0 and Xe_touch < 319 and Ye_touch < 195)
            or (Xe_touch > 0 and Ye_touch >= 195 and Xe_touch < (10 + 100))):

            Affiche_ecran_1_flag = False
            Affiche_ecran_2_flag = True
            Time_Out_screen2 = True

    elif Affiche_ecran_2_flag == True:
        if (Xe_touch >0 and Ye_touch < 195):
            Affiche_ecran_1_flag = True
            Affiche_ecran_2_flag = False

    Touch_press_flag = True

    tft.fill_circle(x, y, 2, ili9341.color565(255, 255, 255))

#-------------------------------------------------------------------------------
# Init liaison spi
spi_tft = machine.SPI(0)
# Init ressource gestion écran TFT
tft = ili9341.Display(spi_tft, dc=TFT_DC_pin, cs=SPI_CS_pin, rst=TFT_RESET_pin, rotation = 0)
# Init des ressources pour gestion de la dalle tactile
Touchscreen = Touch (spi_tft, Touch_Screen_CS_pin, Touch_Interrupt_pin, int_handler = routine_touch,
                     width = 240, height = 320, rotation = 0,
                     x_min = 157, x_max = 1841, y_min = 200, y_max = 1947)
#-------------------------------------------------------------------------------
# Importer police de caractères
unispace = xglcd_font.XglcdFont('fonts/Unispace12x24.c', 12, 24)
tft.draw_text( 2, 10, "Hello", unispace, ili9341.color565(255, 255, 255),  background=0,
                  landscape=False, spacing=5)
time.sleep (2)
tft.clear()
tft.draw_text(30, 150, "Touchez l'ecran", unispace,
                  ili9341.color565(255, 255, 255))
while True :
    pass