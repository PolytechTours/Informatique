# Module Affichage_Graphique.py
# Gestion des affichages graphique écran LCD

# fonts/UnispaceExt12x24
LARGEUR_CARACT = const (12)
HAUTEUR_CARACT = const (24)

from ILI9341 import *
from xglcd_font import *
from Colorimetrie import *
import xpt2046
from machine import PWM, Pin, SPI
from ConfigMateriel_pico import *


unispace = XglcdFont('fonts/Unispace12x24.c', 12, 24)

# Initialize TFT screen
#spi = SPI(1, baudrate=40000000, polarity=1, phase=1, sck=machine.Pin(TFT_SCK_pin), mosi=machine.Pin(TFT_MOSI_pin))
#tft = ILI9341(spi, cs=machine.Pin(TFT_CS_pin), dc=machine.Pin(TFT_DC_pin), rst=machine.Pin(TFT_RST_pin))

# Définition de couleur de base
BLANC = const (0xFFFF)
NOIR = const (0x0000)
ROUGE = const (0xF800)
VERT = const (0x07E0)
CYAN = const (0x07FF)
BLEU = const (0x001F)
LIGHTGREY =  const(0xAD75)
MEDIUMGREY = const (0x8410)
DARKGREY = const (0x4A49)

# Définition des niveaux de rétroéclairage en valeur de pwm sur 2 octets
BACKLITE_0 = const(65535) # Rétroéclairage Max
BACKLITE_1 = const(32768) # 2^15
BACKLITE_2 = const(16394) # 2^14
BACKLITE_3 = const(8192)  # 2^13
BACKLITE_4 = const(0) # Rétroéclairage éteint

COV_MIN = const(0)
CO2_MIN = const(400)
COV_MAX = const(500)
CO2_MAX = const(4000)

# Ecran 1
# Définition de constantes symboliques liées à la mise en forme de l'écran 1

# A compléter selon besoins


# Ecran 2
# Définition de constantes symboliques liées à la mise en forme de l'écran 2
#   Tableau des valeurs min et max
#       A compléter selon besoins

#   Bouton Reset
#       A compléter selon besoins

#   Echelle de rétroéclairage
#       A compléter selon besoins

class TFT_affichage :

    def __init__ (self, tft = None, unispaceExt = None) :

        """
        Args:
        TFT_affichage (Class ili9341) :  tft interface pour écran TFT
        unispaceExt (Class xglcd_font) : police de caractère
        """
        if tft is None:
            raise ValueError('An tft object is required.')
        self.tft = tft
        if unispaceExt is None:
            raise ValueError('An unispaceExt object is required.')
        self.unispaceExt = unispaceExt
        self.indexBrightness = 0
        self.pwm = PWM(Pin(3))  #en commentaire pour le moment car nous fait planter l'ecran
        self.pwm.freq(1000)
        self.pwm.duty_u16(BACKLITE_0)
        
#---------------------------------------------------------------------------------------------
# Afficher un bouton + légende centrée
    def bouton (self, x, y, w, h, couleur_fond, police, texte, couleur_texte) :
        self.tft.fill_hrect (x, y, w, h, couleur_fond)
        self.tft.draw_rectangle (x, y, w, h, BLANC)
        self.tft.draw_text (x + int ((w - len(texte) * LARGEUR_CARACT) // 2), y + (h - HAUTEUR_CARACT) // 2, texte, police, couleur_texte, False, background=couleur_fond,
                  landscape=False, spacing=2)
    
    def affichage_principal(self, temp, hum, pres, co2):
        """
        Args:
        temp (int) : température en °C
        hum (int) : humidité en %
        pres (int) : pression en hPa
        co2 (int) : concentration de CO2 en ppm
        """
        data = [
            ["Température :", str(temp)+" Â°C"],
            ["Pression :", str(pres)+" hPa"],
            ["Humidité :", str(hum)+" %"],
            ["CO2 :", str(co2)+" ppm"],
        ]

        row_height = 30  # Hauteur de chaque ligne
        start_x = 10  # Position x de la premiÃ¨re colonne
        start_y = 10  # Position y de la premiÃ¨re ligne
        
        for i, (label, value) in enumerate(data):
            # Colonne 1 (Ã‰tiquette)
            self.tft.draw_text(start_x, start_y + i * row_height, label, self.unispaceExt, color565(250, 120, 10), background=0, landscape=False, spacing=1)
        
            # Colonne 2 (Valeur)
            self.tft.draw_text(start_x + 180, start_y + i * row_height, value, self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)

        
#---------------------------------------------------------------------------------------------
# Afficher le fond d'écran 1 d'affichage des valeurs de t, p, h, cov et co2
    def fond_ecran1(self):    
        self.tft.draw_text( 35 , 15, "Temp :" , self.unispaceExt, color565(95, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 35 , 45, "Pression :" , self.unispaceExt, color565(95, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 35 , 75, "Humidité :" , self.unispaceExt, color565(95, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 35 , 105, "COV_Index :" , self.unispaceExt, color565(95, 255, 255), background=0, landscape=False, spacing=1)
        
        for i in range(6, 51, 1):
            rectangle_color = Codage_WaveLengthToRGB(380+(i*5))
            self.tft.fill_rectangle( 46+i*4 , 148, 4, 15, color565(rectangle_color[0],rectangle_color[1],rectangle_color[2]))
        
        self.tft.draw_rectangle( 70 , 148 , 180 , 15 , color565(255, 255, 255))
        self.tft.draw_text( 35 , 165, "CO2 :" , self.unispaceExt, color565(95, 255, 255), background=0, landscape=False, spacing=1)
        
        for i in range(0, 32, 1):
            rectangle_color = Codage_WaveLengthToRGB(500+(i*5))
            self.tft.fill_rectangle( 0+i*10 , 208, 10, 15, color565(rectangle_color[0],rectangle_color[1],rectangle_color[2]))
        
        self.tft.draw_rectangle( 0 , 208 , 320 , 15 , color565(255, 255, 255))
    
    def ecran_1(self, temp, hum, pres, co2, cov, last_co2, last_cov):    
        """
        Args:
        temp (str) : température en °C
        hum (str) : humidité en %
        pres (str) : pression en hPa
        co2 (str) : concentration de CO2 en ppm
        cov (str) : concentration de COV en ppb
        last_co2 (int) : concentration de CO2 précédente en ppm
        last_cov (int) : concentration de COV précédente en ppb
        """
        self.tft.draw_text( 110, 15, temp , self.unispaceExt, color565(255, 0, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 165 , 45, pres , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 165 , 75, hum , self.unispaceExt, color565(0, 255, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_text( 170 , 105, cov , self.unispaceExt, color565(0, 255, 0), background=0, landscape=False, spacing=1)
        
        if cov != "wait":
            if last_co2 != None:
                for j in range(0, 5):
                    self.tft.draw_line(int((110/500)*int(last_cov)+5-j)+70, 147-j, int((110/500)*int(last_cov)+5+j )+70, 147-j, color565(0, 0, 0))
            for j in range(0, 5):
                    self.tft.draw_line(int((110/500)*int(cov)+5-j)+70, 147-j, int((110/500)*int(cov)+5+j )+70, 147-j, color565(255, 255, 255))
        
        self.tft.draw_text( 105 , 165, co2 , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        
        if co2 != "wait":
            if last_co2 != "wait":
                for j in range(0, 5):
                    self.tft.draw_line(int((320/5000)*int(last_co2)+5-j), 207-j, int((320/5000)*int(last_co2)+5+j ), 207-j, color565(0, 0, 0))
            for j in range(0, 5):
                    self.tft.draw_line(int((320/5000)*int(co2[:-4])+5-j), 207-j, int((320/5000)*int(co2[:-4])+5+j ), 207-j, color565(255, 255, 255))

    def tableau_ecran_2(self, temp, hum, pres, co2): 
        """
        Args:
        temp (list) : température en °C
        hum (list) : humidité en %
        pres (list) : pression en hPa
        co2 (list) : concentration de CO2 en ppm
        """     
        tempmin = str("+"+str(min(temp))+" °C")
        tempmax = str("+"+str(max(temp))+" °C")
        
        hummin = str(str(min(hum))+" %")
        hummax = str(str(max(hum))+" %")
        
        presmin = str(str(min(pres))+" hPa")
        presmax = str(str(max(pres))+" hPa")
        
        if co2 == []:
            co2min = "wait"
            co2max = "wait"
            co2 = "wait"
        else:
            co2min = str(min(co2))+" ppm"
            co2max = str(max(co2))+" ppm"
            co2 = str(str(co2[-1]))+" ppm"
        
        self.tft.draw_rectangle(110, 10, 100, 35, 0xFFFF)
        self.tft.draw_text(140, 15, "Min" , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(210, 10, 100, 35, 0xFFFF)
        self.tft.draw_text(240, 15, "Max" , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        
        self.tft.draw_rectangle(10, 45, 100, 35, 0xFFFF)
        self.tft.draw_text(35, 50, "Temp" , self.unispaceExt, color565(255, 0, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(110, 45, 100, 35, 0xFFFF)
        self.tft.draw_text(120, 50, tempmin , self.unispaceExt, color565(255, 0, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(210, 45, 100, 35, 0xFFFF)
        self.tft.draw_text(220, 50, tempmax , self.unispaceExt, color565(255, 0, 0), background=0, landscape=False, spacing=1)
            
        self.tft.draw_rectangle(10, 80, 100, 35, 0xFFFF)
        self.tft.draw_text(40, 85, "Hum" , self.unispaceExt, color565(0, 255, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(110, 80, 100, 35, 0xFFFF)
        self.tft.draw_text(140, 85, hummin , self.unispaceExt, color565(0, 255, 0), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(210, 80, 100, 35, 0xFFFF)
        self.tft.draw_text(240, 85, hummax , self.unispaceExt, color565(0, 255, 0), background=0, landscape=False, spacing=1)
        
        self.tft.draw_rectangle(10, 115, 100, 35, 0xFFFF)
        self.tft.draw_text(40, 120, "Pres" , self.unispaceExt, color565(0, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(110, 115, 100, 35, 0xFFFF)
        self.tft.draw_text(120, 120, presmin , self.unispaceExt, color565(0, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(210, 115, 100, 35, 0xFFFF)
        self.tft.draw_text(220, 120, presmax , self.unispaceExt, color565(0, 255, 255), background=0, landscape=False, spacing=1)
        
        self.tft.draw_rectangle(10, 150, 100, 35, 0xFFFF)
        self.tft.draw_text(40, 155, "CO2" , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(110, 150, 100, 35, 0xFFFF)
        self.tft.draw_text(115, 155, co2min , self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        self.tft.draw_rectangle(210, 150, 100, 35, 0xFFFF)
        self.tft.draw_text(215, 155, co2max, self.unispaceExt, color565(255, 255, 255), background=0, landscape=False, spacing=1)
        
        self.tft.fill_rectangle( 10 , 195, 100, 35, color565(255, 0, 0))
        self.tft.draw_rectangle(10, 195, 100, 35, color565(255, 255, 255))
        self.tft.draw_text( 30, 200, "Reset", self.unispaceExt, color565(255, 255, 255), background=color565(255, 0, 0), landscape=False, spacing=1)
        self.Echelle_choix_Gamma(0)

    def Echelle_choix_Gamma(self, i):
        self.tft.fill_rectangle( 151 , 196, 30, 33, color565(255, 255, 255))
        self.tft.fill_rectangle( 181 , 196, 30, 33, color565(192, 192, 192))
        self.tft.fill_rectangle( 211 , 196, 30, 33, color565(128, 128, 128))
        self.tft.fill_rectangle( 241 , 196, 30, 33, color565(64, 64, 64))
        self.tft.fill_rectangle( 271 , 196, 30, 33, color565(0, 0, 0))
        self.tft.draw_rectangle(150, 195, 150, 35, 0xFFFF)
        self.point(i)
        self.set_brightness(self.indexBrightness)

    def set_brightness(self, level):
        if level == 0:
            self.pwm.duty_u16(BACKLITE_0)
        elif level == 1:
            self.pwm.duty_u16(BACKLITE_1)
        elif level == 2:
            self.pwm.duty_u16(BACKLITE_2)
        elif level == 3:
            self.pwm.duty_u16(BACKLITE_3)
        elif level == 4:
            self.pwm.duty_u16(BACKLITE_4)
        else:
            print("Invalid brightness level")

    def point(self, i):
        l=[166,196,226,256,286]
        if self.indexBrightness + i < 0 or self.indexBrightness + i > 4:
            pass
        else :
            self.indexBrightness += i
            self.tft.fill_circle(l[self.indexBrightness], 212, 4, color565(255, 0, 0))